<table border="1" cellspacing="0" cellpadding="5" style="width:100%; font-size:12px;">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Kelas</th>
            <th>Tanggal</th>
            <th>Alasan</th>
        </tr>
    </thead>
    <tbody>
        @foreach($izinMasuk as $izin)
            <tr>
                <td>{{ $izin->user->name }}</td>
                <td>{{ $izin->user->kelas }}</td>
                <td>{{ \Carbon\Carbon::parse($izin->waktu_izin)->format('d/m/Y H:i') }}</td>
                <td>{{ $izin->alasan }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
