

<?php $__env->startSection('content'); ?>
<h2 class="text-xl font-bold mb-6">Ubah Password</h2>

<?php if(session('success')): ?>
    <div class="bg-green-100 text-green-700 p-3 rounded mb-4"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('profile.password.update')); ?>" class="max-w-md space-y-4">
    <?php echo csrf_field(); ?>

    <div>
        <label class="block text-sm">Password Lama</label>
        <input type="password" name="current_password"
               class="w-full border rounded p-2" required>
        <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
        <label class="block text-sm">Password Baru</label>
        <input type="password" name="new_password"
               class="w-full border rounded p-2" required>
    </div>

    <div>
        <label class="block text-sm">Konfirmasi Password Baru</label>
        <input type="password" name="new_password_confirmation"
               class="w-full border rounded p-2" required>
        <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">
            Simpan Password
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ngulik\laravel\ezin-app\resources\views\profile\password.blade.php ENDPATH**/ ?>