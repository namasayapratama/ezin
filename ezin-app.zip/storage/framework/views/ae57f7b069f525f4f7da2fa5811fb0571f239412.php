

<?php $__env->startSection('content'); ?>
<h2 class="text-xl font-bold mb-6">Data Izin Keluar</h2>

<form method="GET" class="mb-6 flex flex-wrap gap-4 items-end">
    <div>
        <label class="block text-sm">Cari Nama</label>
        <input type="text" name="search" value="<?php echo e(request('search')); ?>"
            class="border rounded p-2 w-48" placeholder="Nama Siswa">
    </div>

    <div>
        <label class="block text-sm">Kelas</label>
        <select name="kelas" class="border rounded p-2 w-40">
            <option value="">Semua</option>
            <?php $__currentLoopData = $daftarKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($kelas); ?>" <?php echo e(request('kelas') == $kelas ? 'selected' : ''); ?>>
                    <?php echo e($kelas); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div>
        <label class="block text-sm">Dari Tanggal</label>
        <input type="date" name="start_date" value="<?php echo e($start); ?>" class="border rounded p-2">
    </div>

    <div>
        <label class="block text-sm">Sampai Tanggal</label>
        <input type="date" name="end_date" value="<?php echo e($end); ?>" class="border rounded p-2">
    </div>

    <div class="flex items-center">
        <input type="checkbox" name="belum_kembali" id="belum_kembali" value="1"
               <?php echo e(request('belum_kembali') ? 'checked' : ''); ?>

               class="mr-2">
        <label for="belum_kembali">Hanya yang belum kembali</label>
    </div>

    <div>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Filter</button>
         <a href="<?php echo e(route('admin.izin-keluar')); ?>"
       class="bg-gray-300 text-gray-700 px-4 py-2 rounded hover:bg-gray-400">
       Reset Filter
    </a>
    </div>

</form>

<div class="mb-4 flex gap-2">
    <a href="<?php echo e(route('admin.izin-keluar.export.excel', request()->query())); ?>"
       class="bg-green-600 text-white px-4 py-2 rounded text-sm fa fa-file-excel-o"> Export Excel</a>

    <a href="<?php echo e(route('admin.izin-keluar.export.pdf', request()->query())); ?>"
       class="bg-red-600 text-white px-4 py-2 rounded text-sm fa fa-file-pdf-o" > Export PDF</a>
</div>

<div class="overflow-x-auto">
    <table class="min-w-full bg-white shadow rounded overflow-hidden">
        <thead class="bg-blue-600 text-white text-sm uppercase text-center">
            <tr>
                <th class="p-3">Nama</th>
                <th class="p-3">Kelas</th>
                <th class="p-3">Tanggal</th>
                <th class="p-3">Alasan</th>
                <th class="p-3">Status</th> 
            </tr>
        </thead>
        <tbody class="text-gray-700 text-sm text-center">
            <?php $__empty_1 = true; $__currentLoopData = $izinKeluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b hover:bg-gray-50">
                    <td class="p-3"><?php echo e($izin->user->name); ?></td>
                    <td class="p-3"><?php echo e($izin->user->kelas); ?></td>
                    <td class="p-3"><?php echo e(\Carbon\Carbon::parse($izin->waktu_izin)->format('d-m-Y H:i')); ?></td>
                    <td class="p-3"><?php echo e($izin->alasan); ?></td>
                    <td class="p-3">
                <?php if(is_null($izin->kembali_pada)): ?>
                    <span class="text-orange-500 font-semibold">Belum</span>
                <?php else: ?>
                    <span class="text-green-600 font-semibold">Sudah</span>
                <?php endif; ?>
            </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="p-4 text-center text-gray-500">Data tidak ditemukan</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4">
    <?php echo e($izinKeluar->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ngulik\laravel\ezin-app\resources\views\admin\izin-keluar.blade.php ENDPATH**/ ?>