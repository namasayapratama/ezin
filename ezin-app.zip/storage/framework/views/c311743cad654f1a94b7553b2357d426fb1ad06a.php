


<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold">Dashboard Siswa</h1>
    <p>Selamat datang, <?php echo e(Auth::user()->name); ?>!</p>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <div class="bg-white rounded shadow p-4">
        <h2 class="text-lg font-bold mb-2">Izin Masuk Bulan Ini</h2>
        <p class="text-3xl text-blue-600 font-semibold"><?php echo e($masukBulanIni); ?></p>
    </div>
    <div class="bg-white rounded shadow p-4">
        <h2 class="text-lg font-bold mb-2">Izin Keluar Bulan Ini</h2>
        <p class="text-3xl text-teal-600 font-semibold"><?php echo e($keluarBulanIni); ?></p>
    </div>
</div>

<div class="mt-10">
    <h3 class="text-lg font-semibold mb-3">Riwayat Izin Masuk Terbaru</h3>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <?php $__empty_1 = true; $__currentLoopData = $riwayatMasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white p-4 rounded shadow">
                <p class="text-sm text-gray-600"><?php echo e(\Carbon\Carbon::parse($izin->waktu_izin)->format('d/m/Y H:i')); ?></p>
                <p class="font-semibold text-gray-800"><?php echo e($izin->alasan); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-2 text-center text-gray-500">
                Belum ada izin masuk.
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="mt-10">
    <h3 class="text-lg font-semibold mb-3">Riwayat Izin Keluar Terbaru</h3>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <?php $__empty_1 = true; $__currentLoopData = $riwayatKeluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white p-4 rounded shadow">
                <p class="text-sm text-gray-600"><?php echo e(\Carbon\Carbon::parse($izin->waktu_izin)->format('d/m/Y H:i')); ?></p>
                <p class="font-semibold text-gray-800"><?php echo e($izin->alasan); ?></p>
                <p class="text-sm mt-1">
                    Status:
                    <?php if(is_null($izin->kembali_pada)): ?>
                        <span class="text-yellow-600 font-medium">Belum Kembali</span>
                    <?php else: ?>
                        <span class="text-green-600 font-medium">Sudah Kembali</span>
                    <?php endif; ?>
                </p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-2 text-center text-gray-500">
                Belum ada izin keluar.
            </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ngulik\laravel\ezin-app\resources\views\siswa\dashboard.blade.php ENDPATH**/ ?>