<table border="1" cellspacing="0" cellpadding="5" style="width:100%; font-size:12px;">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Kelas</th>
            <th>Tanggal</th>
            <th>Alasan</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $izinMasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($izin->user->name); ?></td>
                <td><?php echo e($izin->user->kelas); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($izin->waktu_izin)->format('d/m/Y H:i')); ?></td>
                <td><?php echo e($izin->alasan); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH F:\ngulik\laravel\ezin-app\resources\views\admin\exports\izin-masuk-excel.blade.php ENDPATH**/ ?>