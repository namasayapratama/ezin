

<?php $__env->startSection('content'); ?>
<?php if(session('email_error')): ?>
    <div class="bg-yellow-100 text-yellow-700 p-3 mb-4 rounded">
        <?php echo e(session('email_error')); ?>

    </div>
<?php endif; ?>

<h2 class="text-xl font-bold mb-4">Izin Keluar Dikirim</h2>
<p>Scan QR Code di workstation untuk mencetak surat izin.</p>

<div class="mt-4">
    <?php echo QrCode::size(200)->generate($izin->uuid); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ngulik\laravel\ezin-app\resources\views\siswa\izin-keluar-result.blade.php ENDPATH**/ ?>