

<?php $__env->startSection('content'); ?>
<h2 class="text-xl font-bold mb-6">Dashboard Admin</h2>



<h1 class="text-lg font-semibold mb-4">Statistik Izin Masuk</h1>
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
    <div class="bg-white shadow rounded p-6">
        <div class="flex justify-between items-center">
            <div class="text-blue-600 text-xl font-semibold">Hari Ini</div>
        </div>
        <div class="mt-4 text-center">
            <div class="text-3xl font-bold text-blue-700"><?php echo e($masukHariIni); ?></div>
            <p class="text-sm text-gray-500">Izin Masuk Hari Ini</p>
        </div>
    </div>

    <div class="bg-white shadow rounded p-6">
        <div class="flex justify-between items-center">
            <div class="text-blue-600 text-xl font-semibold">Minggu Ini</div>
        </div>
        <div class="mt-4 text-center">
            <div class="text-3xl font-bold text-blue-700"><?php echo e($masukMingguIni); ?></div>
            <p class="text-sm text-gray-500">Izin Masuk Minggu Ini</p>
        </div>
    </div>

    <div class="bg-white shadow rounded p-6">
        <div class="flex justify-between items-center">
            <div class="text-blue-600 text-xl font-semibold">Bulan Ini</div>
        </div>
        <div class="mt-4 text-center">
            <div class="text-3xl font-bold text-blue-700"><?php echo e($masukBulanIni); ?></div>
            <p class="text-sm text-gray-500">Izin Masuk Bulan Ini</p>
        </div>
    </div>
</div>


<h1 class="text-lg font-semibold mt-10 mb-4">Statistik Izin Keluar</h1>
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
    <div class="bg-white shadow rounded p-6">
        <div class="flex justify-between items-center">
            <div class="text-blue-600 text-xl font-semibold">Hari Ini</div>
        </div>
        <div class="mt-4 text-center">
            <div class="text-3xl font-bold text-blue-700"><?php echo e($keluarHariIni); ?></div>
            <p class="text-sm text-gray-500">Izin Keluar Hari Ini</p>
        </div>
    </div>

    <div class="bg-white shadow rounded p-6">
        <div class="flex justify-between items-center">
            <div class="text-blue-600 text-xl font-semibold">Minggu Ini</div>
        </div>
        <div class="mt-4 text-center">
            <div class="text-3xl font-bold text-blue-700"><?php echo e($keluarMingguIni); ?></div>
            <p class="text-sm text-gray-500">Izin Keluar Minggu Ini</p>
        </div>
    </div>

    <div class="bg-white shadow rounded p-6">
        <div class="flex justify-between items-center">
            <div class="text-blue-600 text-xl font-semibold">Bulan Ini</div>
        </div>
        <div class="mt-4 text-center">
            <div class="text-3xl font-bold text-blue-700"><?php echo e($keluarBulanIni); ?></div>
            <p class="text-sm text-gray-500">Izin Keluar Bulan Ini</p>
        </div>
    </div>
</div>


<div class="mt-12">
    <h3 class="text-lg font-semibold mb-2">Izin Masuk Terbaru</h3>
    <div class="overflow-x-auto">
        <table class="min-w-full bg-white shadow rounded overflow-hidden">
            <thead class="bg-blue-600 text-white text-center text-sm uppercase">
                <tr>
                    <th class="p-3">Nama</th>
                    <th class="p-3">Alasan</th>
                    <th class="p-3">Waktu</th>
                </tr>
            </thead>
            <tbody class="text-gray-700 text-center">
                <?php $__currentLoopData = $izinMasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="p-3"><?php echo e($izin->user->name); ?></td>
                        <td class="p-3"><?php echo e($izin->alasan); ?></td>
                        <td class="p-3"><?php echo e($izin->waktu_izin); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<div class="mt-10">
    <h3 class="text-lg font-semibold mb-2">Izin Keluar Terbaru</h3>
    <div class="overflow-x-auto">
        <table class="min-w-full bg-white shadow rounded overflow-hidden">
            <thead class="bg-blue-600 text-white text-center text-sm uppercase">
                <tr>
                    <th class="p-3">Nama</th>
                    <th class="p-3">Alasan</th>
                    <th class="p-3">Waktu</th>
                </tr>
            </thead>
            <tbody class="text-gray-700 text-center">
                <?php $__currentLoopData = $izinKeluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="p-3"><?php echo e($izin->user->name); ?></td>
                        <td class="p-3"><?php echo e($izin->alasan); ?></td>
                        <td class="p-3"><?php echo e($izin->waktu_izin); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ngulik\laravel\ezin-app\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>