

<?php $__env->startSection('content'); ?>
<h2 class="text-xl font-bold mb-6">Riwayat Izin Masuk</h2>

<table class="w-full border text-sm">
    <thead class="bg-gray-200">
        <tr>
            <th class="p-2 border">Tanggal</th>
            <th class="p-2 border">Alasan</th>
            
        </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td class="p-2 border"><?php echo e($izin->waktu_izin); ?></td>
            <td class="p-2 border"><?php echo e($izin->alasan); ?></td>
           
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="3" class="p-4 text-center">Belum ada izin masuk.</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ngulik\laravel\ezin-app\resources\views\siswa\riwayat-izin-masuk.blade.php ENDPATH**/ ?>