

<?php if(session('success')): ?>
    <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold">Dashboard Guru</h1>
    <p>Selamat datang, <?php echo e(Auth::user()->name); ?>!</p>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <div class="bg-white rounded shadow p-4">
        <h2 class="text-lg font-bold mb-2">Izin Masuk Hari Ini</h2>
        <p class="text-3xl text-blue-600 font-semibold"><?php echo e($masukHariIni); ?></p>
    </div>

    <div class="bg-white rounded shadow p-4">
        <h2 class="text-lg font-bold mb-2">Izin Keluar Hari Ini</h2>
        <p class="text-3xl text-teal-600 font-semibold"><?php echo e($keluarHariIni); ?></p>
    </div>
</div>

<div class="mt-10">
    <h3 class="text-lg font-semibold mb-3">Siswa Belum Kembali Hari Ini</h3>

    <?php if($belumKembaliHariIni->isEmpty()): ?>
        <p class="text-gray-500">Semua siswa telah kembali.</p>
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <?php $__currentLoopData = $belumKembaliHariIni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded shadow p-4">
                    <p class="text-sm text-gray-600">
                        <strong><?php echo e($izin->user->name); ?></strong> – <?php echo e($izin->user->kelas); ?>

                    </p>
                    <p class="text-sm mt-1">Waktu Izin: <?php echo e(\Carbon\Carbon::parse($izin->waktu_izin)->format('H:i')); ?></p>
                    <p class="text-sm text-gray-700">Alasan: <?php echo e($izin->alasan); ?></p>

                    <form action="<?php echo e(route('guru.izin-kembali', $izin->id)); ?>" method="POST" class="mt-3">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                                onclick="return confirm('Tandai siswa ini sudah kembali?')"
                                class="bg-green-600 hover:bg-green-700 text-white text-sm px-4 py-2 rounded">
                            Tandai Sudah Kembali
                        </button>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ngulik\laravel\ezin-app\resources\views\guru\dashboard.blade.php ENDPATH**/ ?>