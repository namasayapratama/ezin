

<?php $__env->startSection('content'); ?>
<div>
<h2 class=" font-bold text-lg mb-4">Cetak Surat Izin Keluar</h2>
            <table>
                <tr><td><strong>Nama</strong></td><td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;</td><td><?php echo e($izin->user->name); ?></td></tr>
                <tr><td><strong>Kelas</strong></td></td><td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp; </td><td><?php echo e($izin->user->kelas); ?></td></tr>
                <tr><td><strong>Alasan</strong></td></td><td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp; </td><td><?php echo e($izin->alasan); ?></td></tr>
                <tr><td><strong>Waktu</strong></td></td><td> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp; </td><td><?php echo e(\Carbon\Carbon::parse($izin->waktu_izin)->format('d/m/Y H:i')); ?></td></tr>
            </table>
<div class="flex gap-2">
    <!--<a href="<?php echo e(route('workstation.keluar.cetak', $izin->uuid)); ?>"
       class="bg-green-600 text-white px-4 py-2 rounded">Cetak Langsung</a>
    -->
 
<?php if(is_null($izin->dicetak_pada)): ?>
    <button onclick="openPrintModal()" class="bg-blue-600 text-white px-4 py-2 rounded">
        🖨️ Lihat & Cetak Surat
    </button>
<?php else: ?>
    <span class="bg-gray-400 text-white px-4 py-2 rounded inline-block cursor-not-allowed">
        🕒 Sudah Dicetak (<?php echo e(\Carbon\Carbon::parse($izin->dicetak_pada)->format('d/m/Y H:i')); ?>)
    </span>
<?php endif; ?>
</div>
</div>

<div id="printModal" class="fixed inset-0 bg-black bg-opacity-50 z-[999] flex items-center justify-center hidden">
    <div class="bg-white w-[600px] rounded shadow p-6 relative">
        <button onclick="closePrintModal()" class="absolute top-2 right-2 text-gray-600">✖</button>

        <div id="print-area">
            <h3 class="text-center font-bold text-lg mb-4"><?php echo e(\App\Models\Setting::get('school_name')); ?></h3>
            
            <h5 class="text-center font-bold text-lg mb-4">Surat Izin Keluar</h5>
            <table class="w-full">
                <tr><td><strong>Nama</strong></td><td> : </td><td><?php echo e($izin->user->name); ?></td></tr>
                <tr><td><strong>Kelas</strong></td></td><td> : </td><td><?php echo e($izin->user->kelas); ?></td></tr>
                <tr><td><strong>Alasan</strong></td></td><td> : </td><td><?php echo e($izin->alasan); ?></td></tr>
                <tr><td><strong>Waktu</strong></td></td><td> : </td><td><?php echo e(\Carbon\Carbon::parse($izin->waktu_izin)->format('d/m/Y H:i')); ?></td></tr>
            </table>

            <div class="mt-6">
                <p>Tanda tangan petugas:</p>
                <br><br>
                <p>________________________</p>
            </div>
            <div class="mt-4">
             <?php echo QrCode::size(150)->generate($izin->uuid); ?>

            </div>
        </div>

        <div class="mt-6 text-center">
            <button onclick="printDiv('print-area')" class="bg-blue-700 text-white px-4 py-2 rounded">
                Cetak
            </button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
    function openPrintModal() {
        document.getElementById('printModal').classList.remove('hidden');
    }

    function closePrintModal() {
        document.getElementById('printModal').classList.add('hidden');
    }

    function printDiv(id) {
    fetch('<?php echo e(route('izin-keluar.mark-printed', $izin->uuid)); ?>', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
            'Content-Type': 'application/json'
        }
    }).then(() => {
        const printContents = document.getElementById(id).innerHTML;
        const originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
        location.reload();
    });
}
   
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ngulik\laravel\ezin-app\resources\views\workstation\result-keluar.blade.php ENDPATH**/ ?>