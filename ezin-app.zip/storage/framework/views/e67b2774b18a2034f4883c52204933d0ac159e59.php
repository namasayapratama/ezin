<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Izin</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 13px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 6px; text-align: left; }
    </style>
</head>
<body>
    <h2>Laporan Izin Siswa</h2>
    <p>Tanggal: <?php echo e($tanggal); ?></p>

    <h3>Izin Masuk</h3>
    <table>
        <thead>
            <tr><th>Nama</th><th>Alasan</th><th>Waktu</th></tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $izinMasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($izin->user->name); ?></td>
                    <td><?php echo e($izin->alasan); ?></td>
                    <td><?php echo e($izin->waktu_izin); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="3">Tidak ada data</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <h3>Izin Keluar</h3>
    <table>
        <thead>
            <tr><th>Nama</th><th>Alasan</th><th>Waktu</th><th>Kembali?</th></tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $izinKeluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($izin->user->name); ?></td>
                    <td><?php echo e($izin->alasan); ?></td>
                    <td><?php echo e($izin->waktu_izin); ?></td>
                    <td><?php echo e($izin->kembali_pada ? 'Ya' : 'Belum'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4">Tidak ada data</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH F:\ngulik\laravel\ezin-app\resources\views\admin\laporan.blade.php ENDPATH**/ ?>