

<?php $__env->startSection('content'); ?>
<h2 class="text-xl font-bold mb-4">Import Data Pengguna</h2>

<?php if(session('success')): ?>
    <div class="mb-4 text-green-600"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<form action="<?php echo e(route('admin.import')); ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
    <?php echo csrf_field(); ?>
    <input type="file" name="file" accept=".xlsx,.xls" required>
    <button class="bg-blue-600 text-white px-4 py-2">Import</button>
</form>

<div class="mt-6">
    <a href="<?php echo e(route('admin.template.download')); ?>" class="text-blue-600 underline">📥 Download Template Excel</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ngulik\laravel\ezin-app\resources\views\admin\import-users.blade.php ENDPATH**/ ?>