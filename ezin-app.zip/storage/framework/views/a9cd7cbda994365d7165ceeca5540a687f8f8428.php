

<?php $__env->startSection('content'); ?>
<h2 class="text-xl font-bold mb-4">Data Pengguna</h2>
<div class="flex justify-between items-center mb-4">
    <a href="<?php echo e(route('admin.users.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded">+ Tambah User</a>

    <a href="<?php echo e(route('admin.import.form')); ?>" class="bg-green-600 text-white px-4 py-2 rounded">
        ⬆️ Import User
    </a>
</div>


<form method="GET" action="<?php echo e(route('admin.users')); ?>" class="flex items-center gap-4 mb-4">
    <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari nama/email"
        class="border p-2 rounded w-64">

    <select name="role" class="border p-2 rounded">
        <option value="">Semua Role</option>
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($role); ?>" <?php echo e(request('role') == $role ? 'selected' : ''); ?>>
                <?php echo e(ucfirst($role)); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <button class="bg-blue-600 text-white px-4 py-2 rounded">Filter</button>
    <a href="<?php echo e(route('admin.users')); ?>" class="text-sm text-gray-500 hover:underline">Reset</a>
</form>

<table class="w-full border text-sm">
    <thead class="bg-gray-200">
        <tr>
            <th class="p-2 border">Nama</th>
            <th class="p-2 border">Email</th>
            <th class="p-2 border">Role</th>
            <th class="p-2 border">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="p-2 border"><?php echo e($user->name); ?></td>
            <td class="p-2 border"><?php echo e($user->email); ?></td>
            <td class="p-2 border"><?php echo e($user->getRoleNames()->first()); ?></td>
            <td class="p-2 border space-x-2">
    <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="text-blue-600 underline">Edit</a>
    <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" class="inline" onsubmit="return confirm('Hapus user ini?')">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <button class="text-red-600 underline">Hapus</button>
    </form>
</td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ngulik\laravel\ezin-app\resources\views\admin\users.blade.php ENDPATH**/ ?>