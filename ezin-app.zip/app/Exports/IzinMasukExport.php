<?php
namespace App\Exports;

use App\Models\IzinMasuk;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class IzinMasukExport implements FromCollection, WithHeadings, WithMapping
{
    protected Collection $data;

    public function __construct(Collection $data)
    {
        $this->data = $data;
    }

    public function collection(): Collection
    {
        return $this->data;
    }

    public function map($izin): array
    {
        return [
            $izin->user->name,
            $izin->user->kelas,
            \Carbon\Carbon::parse($izin->waktu_izin)->format('d/m/Y H:i'),
            $izin->alasan,
        ];
    }

    public function headings(): array
    {
        return ['Nama', 'Kelas', 'Tanggal', 'Alasan'];
    }
}
