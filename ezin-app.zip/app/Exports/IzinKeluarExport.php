<?php 
namespace App\Exports;

use App\Models\IzinKeluar;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class IzinKeluarExport implements FromCollection, WithHeadings, WithMapping
{
    protected $data;

    public function __construct($data) {
        $this->data = $data;
    }

    public function collection()
    {
        return $this->data;
    }

    public function map($izin): array
    {
        return [
            $izin->user->name,
            $izin->user->kelas,
            \Carbon\Carbon::parse($izin->waktu_izin)->format('d/m/Y H:i'),
            $izin->alasan,
        ];
    }

    public function headings(): array
    {
        return ['Nama', 'Kelas', 'Tanggal', 'Alasan'];
    }
}
